package com.phoneinfo.app;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(0xFF0D1117);

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(32, 48, 32, 48);

        // Title
        TextView title = new TextView(this);
        title.setText("📱 Phone Info");
        title.setTextSize(28);
        title.setTextColor(0xFF58A6FF);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, 0, 0, 32);
        mainLayout.addView(title);

        // DEVICE
        mainLayout.addView(createSection("🖥️ ПРИСТРІЙ"));
        mainLayout.addView(createRow("Виробник", Build.MANUFACTURER));
        mainLayout.addView(createRow("Модель", Build.MODEL));
        mainLayout.addView(createRow("Бренд", Build.BRAND));
        mainLayout.addView(createRow("Пристрій", Build.DEVICE));
        mainLayout.addView(createRow("Продукт", Build.PRODUCT));
        mainLayout.addView(createRow("Hardware", Build.HARDWARE));
        mainLayout.addView(createRow("Serial", Build.getSerial() != null ? "Доступно" : "Недоступно"));

        // ANDROID
        mainLayout.addView(createSection("🤖 ANDROID"));
        mainLayout.addView(createRow("Версія Android", Build.VERSION.RELEASE));
        mainLayout.addView(createRow("API рівень", String.valueOf(Build.VERSION.SDK_INT)));
        mainLayout.addView(createRow("Security Patch", Build.VERSION.SECURITY_PATCH));
        mainLayout.addView(createRow("Build ID", Build.ID));
        mainLayout.addView(createRow("Build Type", Build.TYPE));
        mainLayout.addView(createRow("Fingerprint", Build.FINGERPRINT.substring(0, Math.min(40, Build.FINGERPRINT.length())) + "..."));

        // CPU
        mainLayout.addView(createSection("⚙️ ПРОЦЕСОР"));
        mainLayout.addView(createRow("ABI (основний)", Build.SUPPORTED_ABIS[0]));
        mainLayout.addView(createRow("Всі ABI", String.join(", ", Build.SUPPORTED_ABIS)));
        mainLayout.addView(createRow("Ядер CPU", String.valueOf(Runtime.getRuntime().availableProcessors())));
        mainLayout.addView(createRow("CPU Info", getCpuInfo()));
        mainLayout.addView(createRow("CPU Макс. частота", getCpuMaxFreq()));

        // RAM
        mainLayout.addView(createSection("💾 ПАМ'ЯТЬ (RAM)"));
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(memInfo);
        mainLayout.addView(createRow("Загальна RAM", formatBytes(memInfo.totalMem)));
        mainLayout.addView(createRow("Доступна RAM", formatBytes(memInfo.availMem)));
        mainLayout.addView(createRow("Використана RAM", formatBytes(memInfo.totalMem - memInfo.availMem)));
        mainLayout.addView(createRow("Низька пам'ять", memInfo.lowMemory ? "⚠️ Так" : "✅ Ні"));
        mainLayout.addView(createRow("Поріг низької пам'яті", formatBytes(memInfo.threshold)));

        // STORAGE
        mainLayout.addView(createSection("💿 СХОВИЩЕ"));
        StatFs internalStat = new StatFs(Environment.getDataDirectory().getPath());
        long internalTotal = internalStat.getTotalBytes();
        long internalFree = internalStat.getFreeBytes();
        mainLayout.addView(createRow("Внутрішнє (всього)", formatBytes(internalTotal)));
        mainLayout.addView(createRow("Внутрішнє (вільно)", formatBytes(internalFree)));
        mainLayout.addView(createRow("Внутрішнє (зайнято)", formatBytes(internalTotal - internalFree)));

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            StatFs externalStat = new StatFs(Environment.getExternalStorageDirectory().getPath());
            mainLayout.addView(createRow("SD карта (всього)", formatBytes(externalStat.getTotalBytes())));
            mainLayout.addView(createRow("SD карта (вільно)", formatBytes(externalStat.getFreeBytes())));
        } else {
            mainLayout.addView(createRow("SD карта", "Не знайдено"));
        }

        // DISPLAY
        mainLayout.addView(createSection("🖥️ ЕКРАН"));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        mainLayout.addView(createRow("Роздільність", dm.widthPixels + " x " + dm.heightPixels + " px"));
        mainLayout.addView(createRow("Щільність", dm.densityDpi + " dpi"));
        mainLayout.addView(createRow("Масштаб", String.valueOf(dm.density) + "x"));
        mainLayout.addView(createRow("Розмір (dp)", (int)(dm.widthPixels / dm.density) + " x " + (int)(dm.heightPixels / dm.density) + " dp"));
        float screenInches = (float) Math.sqrt(
            Math.pow(dm.widthPixels / dm.xdpi, 2) + Math.pow(dm.heightPixels / dm.ydpi, 2));
        mainLayout.addView(createRow("Діагональ", String.format(Locale.US, "%.1f\"", screenInches)));

        // BATTERY
        mainLayout.addView(createSection("🔋 БАТАРЕЯ"));
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int pct = (int)(level * 100f / scale);
            mainLayout.addView(createRow("Заряд", pct + "%"));

            int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            mainLayout.addView(createRow("Температура", (temp / 10.0f) + "°C"));

            int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
            mainLayout.addView(createRow("Напруга", voltage + " mV"));

            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String statusStr = status == BatteryManager.BATTERY_STATUS_CHARGING ? "⚡ Заряджається" :
                               status == BatteryManager.BATTERY_STATUS_FULL ? "✅ Заряджено" : "🔋 Розряджається";
            mainLayout.addView(createRow("Статус", statusStr));

            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthStr = health == BatteryManager.BATTERY_HEALTH_GOOD ? "✅ Добре" :
                               health == BatteryManager.BATTERY_HEALTH_OVERHEAT ? "🔥 Перегрів" :
                               health == BatteryManager.BATTERY_HEALTH_DEAD ? "💀 Мертва" : "Невідомо";
            mainLayout.addView(createRow("Стан батареї", healthStr));

            String technology = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            mainLayout.addView(createRow("Технологія", technology != null ? technology : "Невідомо"));
        }

        // NETWORK
        mainLayout.addView(createSection("📡 МЕРЕЖА"));
        TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (tm != null) {
            mainLayout.addView(createRow("Оператор", tm.getNetworkOperatorName().isEmpty() ? "Немає SIM" : tm.getNetworkOperatorName()));
            mainLayout.addView(createRow("Країна SIM", tm.getSimCountryIso().toUpperCase()));
            mainLayout.addView(createRow("Тип мережі", getNetworkType(tm.getNetworkType())));
            mainLayout.addView(createRow("Роумінг", tm.isNetworkRoaming() ? "✈️ Так" : "🏠 Ні"));
        }

        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        if (wm != null) {
            mainLayout.addView(createRow("WiFi", wm.isWifiEnabled() ? "✅ Увімкнено" : "❌ Вимкнено"));
            if (wm.isWifiEnabled()) {
                WifiInfo wi = wm.getConnectionInfo();
                if (wi != null && wi.getSSID() != null && !wi.getSSID().equals("<unknown ssid>")) {
                    mainLayout.addView(createRow("WiFi мережа", wi.getSSID().replace("\"", "")));
                    mainLayout.addView(createRow("Сигнал WiFi", wi.getRssi() + " dBm"));
                    mainLayout.addView(createRow("Швидкість WiFi", wi.getLinkSpeed() + " Mbps"));
                }
            }
        }

        // SENSORS
        mainLayout.addView(createSection("🔬 ДАТЧИКИ"));
        SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sm != null) {
            List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
            mainLayout.addView(createRow("Кількість датчиків", String.valueOf(sensors.size())));
            for (Sensor s : sensors) {
                mainLayout.addView(createRow("  • " + s.getName(), s.getVendor()));
            }
        }

        // LOCALE
        mainLayout.addView(createSection("🌍 МОВА ТА РЕГІОН"));
        mainLayout.addView(createRow("Мова", Locale.getDefault().getDisplayLanguage()));
        mainLayout.addView(createRow("Країна", Locale.getDefault().getDisplayCountry()));
        mainLayout.addView(createRow("Код мови", Locale.getDefault().toString()));
        mainLayout.addView(createRow("Часовий пояс", java.util.TimeZone.getDefault().getID()));

        scrollView.addView(mainLayout);
        setContentView(scrollView);
    }

    private View createSection(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(16);
        tv.setTextColor(0xFF58A6FF);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, 40, 0, 12);
        return tv;
    }

    private View createRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 6, 0, 6);

        // Divider line
        View divider = new View(this);
        divider.setBackgroundColor(0xFF21262D);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1);
        divider.setLayoutParams(divParams);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextColor(0xFF8B949E);
        labelTv.setTextSize(13);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        labelTv.setLayoutParams(labelParams);

        TextView valueTv = new TextView(this);
        valueTv.setText(value != null ? value : "Невідомо");
        valueTv.setTextColor(0xFFE6EDF3);
        valueTv.setTextSize(13);
        valueTv.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        valueTv.setLayoutParams(valueParams);

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(row);
        row.addView(labelTv);
        row.addView(valueTv);
        wrapper.addView(divider);

        return wrapper;
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 B";
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int idx = (int)(Math.log(bytes) / Math.log(1024));
        idx = Math.min(idx, units.length - 1);
        return String.format(Locale.US, "%.1f %s", bytes / Math.pow(1024, idx), units[idx]);
    }

    private String getCpuInfo() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/cpuinfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Hardware") || line.startsWith("model name") || line.startsWith("Processor")) {
                    br.close();
                    return line.split(":")[1].trim();
                }
            }
            br.close();
        } catch (Exception ignored) {}
        return Build.HARDWARE;
    }

    private String getCpuMaxFreq() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(
                "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"));
            String line = br.readLine();
            br.close();
            if (line != null) {
                long freq = Long.parseLong(line.trim());
                return String.format(Locale.US, "%.2f GHz", freq / 1_000_000.0);
            }
        } catch (Exception ignored) {}
        return "Недоступно";
    }

    private String getNetworkType(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_LTE: return "4G LTE";
            case TelephonyManager.NETWORK_TYPE_NR: return "5G";
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA: return "3G HSPA";
            case TelephonyManager.NETWORK_TYPE_EDGE: return "2G EDGE";
            case TelephonyManager.NETWORK_TYPE_GPRS: return "2G GPRS";
            default: return "Невідомо (" + type + ")";
        }
    }
}
